package com.example.myrecyclerview;

import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private List<String> names;

    private RecyclerView mRecyclerView;
    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager mLayoutManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        names = this.getAllNames(); //Rellenamos la lista de nombres

        mRecyclerView = (RecyclerView) findViewById(R.id.recyclerView);
        mLayoutManager = new LinearLayoutManager(this);

        //Declaramos nuestro adaptador
        mAdapter =  new MyAdapter(names, R.layout.recycler_view_item, new MyAdapter.OnItemClickListener() { //creamos una instancia de un objeto que implementa la interfaz onItemClickListener que esta en la clase MyAdapter (la mía)
            @Override                                                                                      // y sobreescribimos el metodo como en cualquier interfaza
            public void onItemClick(String name, int position) {    //podria llegarle cualquier objeto de nuestro modelo, strin en este caso
                Toast.makeText(MainActivity.this, name + " - " + position, Toast.LENGTH_LONG).show();
            }
        });
        //Le adjuntamos nuestro adaptador y el layout
        mRecyclerView.setLayoutManager(mLayoutManager);
        mRecyclerView.setAdapter(mAdapter);

    }

    //para rellenar la lista
    private List<String> getAllNames(){
        return new ArrayList<String>(){{
            add("Alejandro");
            add("Jose");
            add("Barrera");
            add("Ruben");
            add("Antonio");
            add("Ruben");
        }};
    }
}
